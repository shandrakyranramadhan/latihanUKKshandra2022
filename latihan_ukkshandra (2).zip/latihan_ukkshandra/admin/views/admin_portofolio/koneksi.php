<?php 
$koneksi = mysqli_connect("localhost", "root", "", "portopolio_shandraa");