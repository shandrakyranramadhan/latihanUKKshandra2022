<?php 

class App
{
    protected $ctr = 'Portofolio';
    protected $mtd = 'index';
    protected $prm = [];

    public function __construct()
    {
        $url = $this->parseURL();
        //pengkondisian controller
        if (file_exists('../admin/controllers/' . $url[0] . '.php')) {
            $this->ctr = $url[0];
            unset($url[0]);
        }

        require_once '../admin/controllers/' . $this->ctr . '.php';
        $this->ctr = new $this->ctr;
        //pengkondisian method
        if (isset($url[1])) {
            if (method_exists($this->ctr, $url[1])) {
                $this->mtd = $url[1];
                unset($url[1]);
            }
        }

        //pemberian parameter
        if (!empty($url)) {
            $this->prm = array_values($url);
        }

        call_user_func_array([$this->ctr, $this->mtd], $this->prm);
    }

    public function parseURL()
    {
        if (isset($_GET['url'])) {
            //menghilangkan garis miring(/) di akhir url
            $url = rtrim($_GET['url'],'/');

            //menghilangkar karakter aneh atau karakter yang memungkinkan kita di hack
            $url = filter_var($url, FILTER_SANITIZE_URL);

            //menghilangkan tanda garis miring (/) dan mengambil string-nya.
            $url = explode('/', $url);
            return $url;
        }
    }

}