<?php
  include "header.php";
?>
<?php
  include "menu.php";
?>

<?php
  require 'functions.php';
  $User = mysqli_fetch_assoc($a);
  $About = mysqli_fetch_assoc($b);
  
  $projects = data("SELECT * FROM Project");
  if(isset($_POST["submit"])){
      
      if(tambah($_POST) > 0){
          echo "
          <script>
               alert('Data berhasil dikirim');
          </script>
          ";
      }
      else {
          echo "gagal terkirim";
      }
  }
  
?>

  <div class="container-fluid px-2 px-md-4">
      <div class="row justify-content-center">
      </div>
      <div class="card card-body border-radius-xl mt-4 min-height-300">
            <div class="col-12 col-xl-4">
              <div class="card card-plain h-100">
                <div class="card-header pb-0 p-3">
                  <div class="row">
                    <div class="col-md-8 d-flex align-items-center">
                      <h6 class="mb-0">About Me</h6>
                    </div>
                    <div class="col-md-4 text-end">
                      <a href="javascript:;">
                        <i class="fas fa-user-edit text-secondary text-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Profile"></i>
                      </a>
                    </div>
                  </div>
                </div>
                <div class="card-body p-3">
                  <p class="text-sm">  </p>
                  <div class="cold-md-4 text-center"><?=$About["coloum1"];?></p>
         </div>
                  <div class="col-md-4 text-center">
            <p><?=$About["coloum2"];?></p>
          </div>
                  <hr class="horizontal gray-light my-4">
                  <ul class="list-group">
                    <li class="list-group-item border-0 ps-0 pt-0 text-sm"><strong class="text-dark">Full Name:</strong> &nbsp; Alec M. Thompson</li>
                    <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Mobile:</strong> &nbsp; (44) 123 1234 123</li>
                    <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Email:</strong> &nbsp; alecthompson@mail.com</li>
                    <li class="list-group-item border-0 ps-0 text-sm"><strong class="text-dark">Location:</strong> &nbsp; USA</li>
                    <li class="list-group-item border-0 ps-0 pb-0">
                      <strong class="text-dark text-sm">Social:</strong> &nbsp;
                      <a class="btn btn-facebook btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;">
                        <i class="fab fa-facebook fa-lg"></i>
                      </a>
                      <a class="btn btn-twitter btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;">
                        <i class="fab fa-twitter fa-lg"></i>
                      </a>
                      <a class="btn btn-instagram btn-simple mb-0 ps-1 pe-2 py-0" href="javascript:;">
                        <i class="fab fa-instagram fa-lg"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            </div>

</div>
<?php
  include "footer.php";
?>
